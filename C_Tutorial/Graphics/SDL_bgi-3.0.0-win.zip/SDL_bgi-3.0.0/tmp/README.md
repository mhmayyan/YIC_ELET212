These are helper programs:

- `bgi_palette.png` is a screenshot taken from Turbo C 2.01 running in
  DosBox. The `bgi_orig_palette` palette uses colours picked up from this
  file.

- `chr_decoder.c` dumps a `.CHR` font in a more readable format.

- `dumpchar.c` is used to dump VGA characters used by Turbo C 2.01 in
  DosBox.

- `icon.c` writes the `icon.bmp` icon, later converted to PNG.

- `truncate.c` shows a bug in Turbo C 2.01; text is not truncated out
  of the viewport as it should be. This bug is fixed in Turbo C++ 3.
